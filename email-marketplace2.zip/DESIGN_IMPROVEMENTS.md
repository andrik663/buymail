# Design Improvements - Version 2.0

## 1. CHAT P2P (INBOX) - Professional Two-Panel Layout

### Layout Structure
```
┌─────────────────────────────────────────────────────────────┐
│ Header: User Profile                    📧 🔔 👤            │
├──────────────────┬──────────────────────────────────────────┤
│                  │                                          │
│  CHAT LIST       │  CHAT AREA                              │
│  (280px)         │  (Flex-1)                               │
│                  │                                          │
│  ┌────────────┐  │  ┌─────────────────────────────────┐   │
│  │ Search bar │  │  │ Header: Penjual A ⭐ 4.8      │   │
│  │ Filters    │  │  │ 📋 🚫 🚩                        │   │
│  ├────────────┤  │  ├─────────────────────────────────┤   │
│  │ Chat 1  🔵 │  │  │ Messages                        │   │
│  │ Chat 2  ⚪ │  │  │ ┌─────────────┐                │   │
│  │ Chat 3  ⚪ │  │  │ │ Other msg   │ 10:30 ✓        │   │
│  │          🔴  │  │ └─────────────┘                │   │
│  │ Chat 4  ⚪ │  │         ┌──────────────────┐      │   │
│  │            │  │         │ My msg  ✓✓       │      │   │
│  └────────────┘  │         └──────────────────┘      │   │
│                  │ ├─────────────────────────────────┤   │
│                  │ │ [Input] [Send button]           │   │
│                  │ └─────────────────────────────────┘   │
│                  │                                          │
└──────────────────┴──────────────────────────────────────────┘
```

### Key Features
- **Left Sidebar:**
  - Search input dengan icon 🔍
  - Filter buttons: "Semua" | "Belum Dibaca" | "Aktif"
  - Chat list dengan avatar, name, last message
  - Unread counter (badge red)
  - Hover state + selected highlight
  
- **Right Chat Area:**
  - Header dengan info penjual (avatar, nama, rating)
  - Action icons: Archive, Block, Report
  - Messages dengan bubble styling
  - Timestamp + read status indicator
  - Input area dengan send button
  
### Color Scheme
- Selected chat: Blue-50 background + left border Blue-600
- User message: Blue-600 background, white text, rounded-br-none
- Other message: White background, dark text, rounded-bl-none
- Hover: Gray-50 background
- Unread badge: Blue-600 background, white text

---

## 2. SEARCH EMAIL - Filter dengan Submit Button

### Layout
```
┌─────────────────────────────────────────────────────────────┐
│                    SEARCH PAGE                              │
├───────────────────┬──────────────────────────────────────────┤
│                   │                                          │
│  FILTER SIDEBAR   │  RESULTS AREA                           │
│  (280px, sticky)  │  (Flex-1)                               │
│                   │                                          │
│ ┌─────────────┐   │  DITEMUKAN 8 EMAIL                     │
│ │ Filter      │   │  [Tampilkan 12 ▼]                     │
│ ├─────────────┤   │                                          │
│ │ Provider    │   │  ┌─────────┐ ┌─────────┐ ┌─────────┐  │
│ │ [✓] Gmail   │   │  │Email    │ │Email    │ │Email    │  │
│ │ [✓] Outlook │   │  │abc@... │ │def@... │ │ghi@... │  │
│ │ [ ] Yahoo   │   │  │📧Gmail  │ │🔵Outlk │ │🟣Yahoo  │  │
│ │             │   │  │4 tahun  │ │6 tahun  │ │5 tahun  │  │
│ │ Harga       │   │  │✓ Ver    │ │✓ Ver    │ │✗ Ver    │  │
│ │ Min: [____] │   │  │Garan 7d │ │Garan14d │ │Garan3d  │  │
│ │ Max: [____] │   │  │Penjual A│ │Penjual B│ │Penjual C│  │
│ │             │   │  │★4.8(243)│ │★4.9(156)│ │★4.7(89) │  │
│ │ HP Terverif │   │  │Rp45.000 │ │Rp35.000 │ │Rp25.000 │  │
│ │ [✓] Ya      │   │  │[Detail][♥][💬]    │[Detail][♥][💬]  │
│ │             │   │  │         │         │         │       │
│ │ Rating Min  │   │  │ ┌─────────┐ ┌─────────┐ ┌─────────┐│
│ │ [⭐ 4.0+] │   │  │ │...      │ │...      │ │...      ││
│ │             │   │  │ └─────────┘ └─────────┘ └─────────┘│
│ │             │   │                                          │
│ │[Terapkan]   │   │  [Sebelumnya] [1] [2] [3] [Selanjutnya] │
│ │[Reset]      │   │                                          │
│ └─────────────┘   │                                          │
└───────────────────┴──────────────────────────────────────────┘
```

### Key Changes
- **Filter Section:**
  - Sticky positioning untuk easy access saat scroll
  - Clear section divisions dengan border-bottom
  - Action buttons at bottom:
    - "Terapkan Filter" (Blue-600) - primary
    - "Reset Filter" (Gray-200) - secondary
  
- **Results Display:**
  - Shows total email count
  - Dropdown untuk items per page
  - Compact 3-column grid
  
- **Email Card:**
  - Compact spacing (p-4)
  - Email address prominent (font-mono, bold)
  - Info row: Icon + provider + divider + age
  - Verification badge (green)
  - Garansi badge (blue)
  - Seller info section with rating
  - Large price display
  - 3 action buttons: Detail, Heart, Message

---

## 3. EMAIL LIST - Compact Grid Layout

### Card Structure (per email)
```
┌──────────────────────────────┐
│ a***@gmail.com              │ ← font-mono, text-sm, bold
│ 📧 Gmail • 4 tahun          │ ← text-xs, secondary
│ ✓ HP Terverifikasi          │ ← green badge
│ Garansi 7 hari              │ ← blue badge
│ ────────────────────────────│ ← border divider
│ Penjual A                    │ ← seller name
│ ★★★★★ 4.8 (243)            │ ← rating with star
│                             │
│ Rp 45.000                   │ ← large price (text-2xl, bold)
│ Termasuk fee marketplace    │ ← note (text-xs, gray)
│ ────────────────────────────│ ← border divider
│ [Lihat Detail][♥][💬]       │ ← 3 action buttons
└──────────────────────────────┘
```

### Spacing Details
- Card padding: p-4 (16px)
- Gap between sections: mb-3, mb-4
- Button row: px-4 pb-4, flex gap-2
- Section divider: pb-4 border-b border-gray-100
- Flex layout: flex flex-col (content top), flex-1 (spacer), buttons bottom

### Grid Responsive
- **Desktop (lg):** 3 columns
- **Tablet (md):** 2 columns  
- **Mobile:** 1 column
- Gap: gap-4 (16px between cards)

### Typography Hierarchy
1. Email: text-sm, font-mono, font-semibold
2. Info: text-xs, secondary text (gray-600)
3. Badges: text-xs, font-medium, inline-flex
4. Seller: text-sm, font-medium
5. Rating: text-xs, mix of symbol (★) + numbers
6. Price: text-2xl, font-bold, eye-catching
7. Fee note: text-xs, gray-500

### Color Palette
- Card background: white
- Card shadow: shadow-sm (hover: shadow-md)
- Dividers: border-gray-100
- Badges: bg-green-50 text-green-700 (verified), bg-blue-50 text-blue-700 (garansi)
- Buttons: Blue-600 primary, gray border secondary
- Text: gray-900 (primary), gray-600 (secondary), gray-500 (tertiary)

---

## 4. DETAIL PAGE - Improved Spacing

### Layout Changes
- **Left column:** 2 columns on lg, full on smaller
- **Right sidebar:** Sticky top-24 pada large screens
- **Sections:** 
  - Email info card (p-5)
  - Verification status (p-5)
  - Description (p-5)
  - Screenshots (p-5, 2-column grid)
  
- **Seller card (sticky):**
  - Avatar + name + rating (flex gap-3)
  - Divider with border-b border-gray-100
  - Price section (prominent)
  - Garansi badge with check icon
  - Action buttons full-width with gap-3

### Typography
- Section titles: text-sm, font-bold, UPPERCASE
- Labels: text-xs, font-medium, UPPERCASE, tracking-wide
- Body text: text-sm or text-base
- Price: text-3xl, font-bold

### Spacing Consistency
- All cards: p-5 (20px padding)
- Section gaps: mb-6 (24px)
- Internal gaps: mb-3, mb-4
- Button padding: py-3 (vertical), py-2.5
- Button gap: gap-2

---

## Design Tokens Summary

### Spacing Scale
```
p-3   = 12px
p-4   = 16px
p-5   = 20px
p-6   = 24px
gap-2 = 8px
gap-3 = 12px
gap-4 = 16px
mb-3  = 12px
mb-4  = 16px
mb-6  = 24px
```

### Color Palette
```
Primary:        Blue-600 (#2563EB)
Primary hover:  Blue-700 (#1D4ED8)
Secondary:      Gray-600 (#4B5563)
Success:        Green-600 (#16A34A) / Green-50 (#F0FDF4)
Info:           Blue-50 (#EFF6FF)
Muted:          Gray-500 (#6B7280)
Borders:        Gray-100 (#F3F4F6) / Gray-200 (#E5E7EB) / Gray-300 (#D1D5DB)
Background:     Gray-50 (#F9FAFB) / White (#FFFFFF)
Text primary:   Gray-900 (#111827)
Text secondary: Gray-600 (#4B5563)
Text tertiary:  Gray-500 (#6B7280)
```

### Typography
```
Font family: System sans-serif (Inter, Plus Jakarta Sans recommended)

Heading 1: text-3xl, font-bold
Heading 2: text-2xl, font-bold
Heading 3: text-lg, font-bold
Heading 4: text-base, font-semibold
Label:     text-xs, font-bold, UPPERCASE, tracking-wide
Body:      text-sm / text-base, font-normal / font-medium
Small:     text-xs, font-normal / font-medium
Mono:      font-mono, for email addresses
```

### Border Radius
```
Buttons, inputs, cards: rounded-lg (0.5rem = 8px)
Avatars: rounded-full
Small badges: rounded (0.25rem = 4px)
```

### Transitions
```
Colors: transition-colors (default 200ms)
Shadows: transition-shadow (default 200ms)
Transform: transition-transform (default 200ms)
```

---

## Before vs After Comparison

| Aspect | Before | After |
|--------|--------|-------|
| Chat Layout | Simple input | Professional 2-panel |
| Chat Styling | Basic | Bubble design, read status |
| Filter Submit | Auto apply | Explicit submit button |
| Email Cards | Loose spacing | Compact, organized |
| Typography | Inconsistent | Clear hierarchy |
| Spacing | Random | Consistent scale |
| Color | Basic | Professional palette |
| Hover States | Minimal | Smooth transitions |
| Sticky Elements | None | Sidebar + header |
| Responsive | Basic | Optimized grids |

