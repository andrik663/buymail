# EmailMarket - Platform Jual Beli Email Premium

Platform e-commerce yang modern, aman, dan terpercaya untuk jual beli email akun premium (Gmail, Outlook, Yahoo, Custom Domain) dan leads email marketing yang sudah terverifikasi.

## 📋 Daftar Isi

- [Fitur Utama](#fitur-utama)
- [Struktur Proyek](#struktur-proyek)
- [Halaman & Komponen](#halaman--komponen)
- [Panduan Penggunaan](#panduan-penggunaan)
- [Teknologi yang Digunakan](#teknologi-yang-digunakan)
- [Setup & Development](#setup--development)

## ✨ Fitur Utama

### A. HALAMAN PUBLIK (Sebelum Login)

#### 1. **Halaman Beranda** (`/`)
- Header navigasi dengan menu (Beranda, Cari Email, Cara Kerja, FAQ, Masuk/Daftar)
- Hero section dengan CTA buttons
- Statistik cepat (total email terjual, penjual terverifikasi, tingkat kepuasan)
- Kategori email populer (4 kategori dengan grid)
- Cara kerja (3 langkah sederhana)
- Testimoni dari pembeli & penjual
- CTA section di akhir halaman
- Footer dengan links penting

#### 2. **Halaman Pencarian Email** (`/search`)
- **Sidebar Filter (Kiri):**
  - Provider (Gmail, Outlook, Yahoo, Custom domain)
  - Harga (slider min-max + input manual)
  - Verifikasi HP (checkbox)
  - Rating penjual minimal
  
- **Grid Hasil Pencarian:**
  - Email (blur sebagian)
  - Provider & umur akun
  - Badge verifikasi
  - Harga
  - Rating penjual
  - Tombol "Detail" & "Tanya Penjual"
  
- **Pagination:** Previous, 1,2,3..., Next
- Sorting: Terbaru, Harga (rendah-tinggi), Rating

#### 3. **Halaman Detail Email** (`/email/:id`)
- **Informasi Email:**
  - Email (blur dengan opsi "Tampilkan setelah login")
  - Provider & umur akun
  - Status verifikasi (checklist: HP, Recovery, 2FA, Suspend)
  - Deskripsi panjang dari penjual
  - Screenshots (zoom modal)
  - Garansi
  
- **Sidebar Kanan:**
  - Harga besar
  - Tombol "Beli Sekarang" (modal konfirmasi)
  - Tombol "Tanya Penjual" (buka chat P2P)
  - Tombol "Simpan ke Wishlist" (love icon)
  - Info penjual (avatar, rating, jumlah ulasan)

### B. AUTENTIKASI

#### 1. **Halaman Login** (`/login`)
- Input email & password
- Show/hide password toggle
- "Ingat saya" checkbox
- "Lupa password?" link
- Link ke halaman daftar
- Demo login info untuk testing

#### 2. **Halaman Daftar** (`/register`)
- Input: nama lengkap, email, password, konfirmasi password
- Pilihan role: Pembeli, Penjual, atau Keduanya
- Terms & Conditions checkbox
- Link ke halaman login

### C. DASHBOARD PEMBELI

**Path:** `/dashboard/buyer/*`

**Menu Sidebar:**
1. **Email Saya** - Daftar email yang sudah dibeli
   - Kartu per email dengan status, tanggal beli, garansi
   - Tombol "Lihat Detail Akses" (password, recovery info)
   - Tombol "Hubungi Penjual" (buka chat)
   - Tombol "Laporkan Masalah" (komplain)
   - Filter status & pencarian

2. **Riwayat Transaksi** - Timeline vertikal
   - Tanggal, email (blur), harga, status pembayaran
   - Tombol "Lihat Invoice" (download PDF)
   - Filter berdasarkan status & periode

3. **Wishlist** - Email yang disimpan
   - Email, harga saat disimpan, harga sekarang
   - Badge "Harga turun!" jika ada perubahan
   - Tombol "Beli Sekarang" & "Hapus"

4. **Saldo & Pembayaran**
   - Saldo saat ini (dengan tombol Top Up)
   - Saldo pending
   - Riwayat top up
   - Tombol "Tarik Saldo"

5. **Pengaturan Akun**
   - Ubah nama, email, password
   - Notifikasi: email untuk chat baru
   - Privasi: sembunyikan status online
   - Tombol "Hapus Akun"

### D. DASHBOARD PENJUAL

**Path:** `/dashboard/seller/*`

**Menu Sidebar:**
1. **Toko Saya (Kelola Email)**
   - Grid listing email dengan kolom: email, status, harga, terjual
   - Tombol "Tambah Email Baru"
   - Tombol edit cepat (icon pensil) & delete
   - Toggle aktif/nonaktif
   - Atur massal (ubah harga %, nonaktifkan, hapus)

2. **Laporan Penjualan**
   - Kartu stats: email terjual bulan ini, pendapatan kotor/bersih, rating
   - Bar chart penjualan per minggu (30 hari)
   - Daftar transaksi terbaru dengan tombol "Lihat Semua"

3. **Penarikan Saldo**
   - Saldo tersedia + tombol "Tarik Saldo"
   - Saldo pending (info cair dalam X hari)
   - Modal: input nominal, pilih metode (bank/e-wallet/USDT)
   - Riwayat penarikan (status: Diproses, Sukses, Gagal)

4. **Rating & Ulasan**
   - Rata-rata rating (bintang)
   - Daftar ulasan: pembeli, rating, komentar, tanggal
   - Tombol "Balas" ulasan
   - Tombol "Laporkan Ulasan"

5. **Pengaturan Akun (Penjual)**
   - Nama toko (bisa beda dari nama pribadi)
   - Deskripsi toko
   - Auto-reply chat (on/off + text)
   - Notifikasi email untuk pesan baru

### E. SISTEM CHAT P2P

**Path:** `/inbox`

**Layout dua kolom:**
- **Kiri:** Daftar chat dengan pencarian, filter, arsipkan, blokir, laporkan
- **Kanan:** Isi chat terpilih

**Fitur Chat:**
- Bubble chat dengan status read (1 centang = terkirim, 2 centang = dibaca)
- Typing indicator
- Upload gambar/file
- Quick reply templates (khusus penjual)
- Timestamp untuk setiap pesan

**Aturan Otomatis:**
- Chat sebelum transaksi: bebas
- Chat setelah transaksi (dalam garansi): penjual wajib respon 24 jam
- Chat diluar garansi: label "Di luar masa garansi"
- Kata kunci (scam, penipuan): notifikasi ke penjual
- Penjual offline > 7 hari: notif ke pembeli

### F. SISTEM KOMPLAIN & DISPUTE

**Alur:**
1. Pembeli ajukan komplain dari halaman "Email Saya"
2. Form pilih jenis masalah, deskripsi, upload bukti (maks 5 file)
3. Status email berubah jadi "Komplain"
4. Penjual terima notifikasi & dapat merespon
5. Jika tidak selesai, eskalasi ke Admin

## 📁 Struktur Proyek

```
src/
├── App.tsx                 # Main app dengan routing & auth context
├── index.css              # Global styles dengan Tailwind
├── main.tsx               # Entry point
├── pages/
│   ├── HomePage.tsx       # Halaman beranda
│   ├── SearchPage.tsx     # Pencarian & daftar email
│   ├── DetailPage.tsx     # Detail email
│   ├── LoginPage.tsx      # Login
│   ├── RegisterPage.tsx   # Register
│   ├── BuyerDashboard.tsx # Dashboard pembeli (5 menu)
│   ├── SellerDashboard.tsx# Dashboard penjual (5 menu)
│   └── InboxPage.tsx      # Chat P2P
├── components/
│   ├── Header.tsx         # Navigation header
│   ├── Footer.tsx         # Footer
│   └── DashboardSidebar.tsx# Sidebar untuk dashboard
└── utils/
    └── cn.ts              # Utility functions
```

## 🎨 Halaman & Komponen

### Publik Pages
- **HomePage** - Kampanye & info
- **SearchPage** - Filter & grid email
- **DetailPage** - Info email + modal beli
- **LoginPage** - Form login
- **RegisterPage** - Form register

### Protected Pages (Perlu Login)
- **BuyerDashboard** - Manajemen sebagai pembeli
  - MyEmails, TransactionHistory, Wishlist, Balance, AccountSettings
- **SellerDashboard** - Manajemen sebagai penjual
  - ManageEmails, SalesReport, Withdrawal, Seller Settings
- **InboxPage** - Chat P2P realtime

### Components
- **Header** - Sticky header dengan navigation, notifications, profile menu
- **Footer** - Footer links & copyright
- **DashboardSidebar** - Sidebar untuk dashboards dengan mobile toggle

## 🔐 Autentikasi & Authorization

**Auth Context:**
- Simpan user info di localStorage
- Cek token sebelum akses protected routes
- User roles: 'buyer', 'seller', atau 'both'

**ProtectedRoute:**
- Redirect ke login jika belum authenticated

## 🎯 Panduan Penggunaan

### Sebagai Pembeli

1. **Daftar/Login**
   - Pilih role "Saya mau beli email" atau "Keduanya"

2. **Cari Email**
   - Gunakan filter di halaman search
   - Klik "Detail" untuk lihat spesifikasi lengkap

3. **Beli Email**
   - Klik "Beli Sekarang" → Modal konfirmasi
   - Pilih metode pembayaran
   - Bayar & email masuk ke dashboard

4. **Kelola Email**
   - Di "Email Saya" lihat akses (password, recovery)
   - Chat penjual jika ada masalah
   - Laporkan jika ada issue

### Sebagai Penjual

1. **Daftar/Login**
   - Pilih role "Saya mau jual email" atau "Keduanya"

2. **Upload Email**
   - Klik "Tambah Email Baru"
   - Isi: email, provider, umur, harga, status verifikasi, garansi
   - Opsional: deskripsi, screenshots

3. **Kelola Toko**
   - Edit harga, atur stok, nonaktifkan listing
   - Lihat laporan penjualan & rating

4. **Terima Pembayaran**
   - Transaksi masuk otomatis
   - Tarik saldo ke bank/e-wallet

5. **Customer Service**
   - Respon chat di "Pesan"
   - Handle komplain pembeli

## 💻 Teknologi yang Digunakan

- **Framework:** React 19.2.3
- **Build Tool:** Vite 7.2.4
- **Styling:** Tailwind CSS 4.1.17
- **Routing:** React Router DOM 6.x
- **Icons:** Lucide React
- **Language:** TypeScript
- **State:** React Context API + useState

## 🚀 Setup & Development

### Prerequisites
- Node.js 16+
- npm atau yarn

### Installation

```bash
# Clone atau download project
cd emailmarket

# Install dependencies
npm install

# Development server
npm run dev

# Build untuk production
npm run build

# Preview build
npm run preview
```

### Demo Login
- Email: `pembeli@example.com`
- Password: `password123`

## 📊 Mock Data

Aplikasi menggunakan mock data untuk:
- Daftar email (12 item dengan variasi provider & harga)
- Chat messages (contoh percakapan)
- Transaksi history
- Seller stats & ratings

## 🎨 Design System

### Warna
- **Primary:** Blue (#0066CC / #2563EB)
- **Success:** Green (#22C55E)
- **Warning:** Yellow (#FBBF24)
- **Error:** Red (#EF4444)
- **Neutral:** Gray (50-900)

### Typography
- **Font:** System font (sans-serif)
- **Heading:** Bold, sizes 24-48px
- **Body:** Regular, 14-16px

### Spacing
- Base unit: 4px
- Standard: 8px, 16px, 24px, 32px

### Komponen
- Buttons: Primary (blue), Secondary (border), Ghost
- Cards: White background, subtle shadow
- Inputs: Border style dengan focus ring
- Modals: Center overlay dengan backdrop
- Tables: Striped rows, hover effect

## 📱 Responsivitas

- **Desktop:** Full layout dengan sidebar
- **Tablet:** Adjusted grid & font sizes
- **Mobile:** Stack layout, hamburger menu, mobile-first design

## 🔒 Keamanan

- Email blur sebagian (e***@gmail.com)
- Password input dengan show/hide toggle
- HTTPS recommended untuk production
- Token-based auth (implemented dengan localStorage untuk demo)

## 🚧 Future Enhancements

- [ ] Payment gateway integration (Stripe, Midtrans)
- [ ] Email verification flow
- [ ] Admin panel untuk moderasi
- [ ] Real-time notifications (WebSocket)
- [ ] Advanced analytics & reports
- [ ] Email verification bulk upload
- [ ] API backend integration
- [ ] Dark mode toggle
- [ ] Multi-language support
- [ ] Escrow payment system

## 📝 Lisensi

Private project - EmailMarket Platform

## 💬 Support

Untuk pertanyaan atau bug reports, silakan hubungi tim support.

---

**Status:** ✅ Ready for Demo & Development  
**Last Updated:** 2025  
**Version:** 1.0.0
