# EmailMarket Development Guide

## 🗺️ Routes Map

### Public Routes (No Auth Required)
| Path | Component | Description |
|------|-----------|-------------|
| `/` | HomePage | Landing page dengan hero, stats, kategori, cara kerja, testimoni |
| `/search` | SearchPage | Pencarian email dengan filter sidebar dan grid hasil |
| `/email/:id` | DetailPage | Detail email dengan modal beli |
| `/login` | LoginPage | Form login dengan demo credentials |
| `/register` | RegisterPage | Form register dengan pilihan role |

### Protected Routes (Auth Required)
| Path | Component | Description |
|------|-----------|-------------|
| `/dashboard/buyer/*` | BuyerDashboard | Dashboard pembeli dengan 5 menu |
| `/dashboard/seller/*` | SellerDashboard | Dashboard penjual dengan 5 menu |
| `/inbox` | InboxPage | Chat P2P (tersedia untuk buyer & seller) |

### Auth Flow
```
Visitor → /login atau /register
↓
Set User in localStorage & AuthContext
↓
Redirect ke /dashboard/buyer atau /dashboard/seller
↓
Protected routes accessible, Header shows user info
```

## 🔑 Key Features Implementation

### 1. Authentication (Auth Context)

**File:** `src/App.tsx`

```typescript
// Context API approach
const AuthContext = createContext<AuthContextType | undefined>(undefined);

// Hook untuk akses di komponen
export const useAuth = () => useContext(AuthContext);

// ProtectedRoute component
<ProtectedRoute>
  <Dashboard />
</ProtectedRoute>
```

**User Object:**
```typescript
interface User {
  id: string;
  name: string;
  email: string;
  role: 'buyer' | 'seller' | 'both';
  avatar?: string;
  isOnline?: boolean;
}
```

### 2. Search & Filter System

**File:** `src/pages/SearchPage.tsx`

**Filter State:**
```typescript
const [filters, setFilters] = useState({
  provider: [] as string[],      // Multiple select
  minPrice: 0,
  maxPrice: 100000,
  verified: false,               // Boolean
  rating: 3,                     // Number
});
```

**Filtering Logic:**
- Provider: Array includes check
- Price: Range min-max
- Verified: Boolean AND
- Rating: Greater than or equal

**Pagination:**
- Items per page: 12, 24, 48
- Current page state
- Total pages calculated from filtered length

### 3. Dashboard Navigation

**File:** `src/components/DashboardSidebar.tsx`

**Sidebar Features:**
- Sticky on desktop, mobile toggle button
- Active route highlighting
- User role badge
- Logout button
- Responsive animation

**Usage:**
```typescript
// Untuk Buyer
const sidebarItems = [
  { label: 'Email Saya', href: '/dashboard/buyer/emails', icon: <Mailbox /> },
  { label: 'Riwayat Transaksi', href: '/dashboard/buyer/history', icon: <History /> },
  // ... more items
];

// Untuk Seller
const sidebarItems = [
  { label: 'Toko Saya', href: '/dashboard/seller/manage', icon: <Package /> },
  { label: 'Laporan Penjualan', href: '/dashboard/seller/report', icon: <BarChart3 /> },
  // ... more items
];
```

### 4. Chat P2P Implementation

**File:** `src/pages/InboxPage.tsx`

**Chat Structure:**
```typescript
interface ChatMessage {
  id: number;
  sender: 'user' | 'other';
  text: string;
  timestamp: string;
  read: boolean;
}

interface Chat {
  id: number;
  otherUser: { id; name; avatar; rating };
  lastMessage: string;
  lastMessageTime: string;
  unread: number;
  messages: ChatMessage[];
}
```

**Key Interactions:**
- Select chat → Load messages
- Type & send message → Update state & UI
- Message bubbles: different colors for sender/receiver
- Typing indicator (can be added)
- Read receipts (1 checkmark = sent, 2 = read)

### 5. Modal & Forms

**Modal Pattern:**
```typescript
const [showModal, setShowModal] = useState(false);

{showModal && (
  <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
    <div className="bg-white rounded-lg shadow-lg max-w-md w-full p-6">
      {/* Modal content */}
    </div>
  </div>
)}
```

**Form Pattern:**
```typescript
const [formData, setFormData] = useState({...});

const handleSubmit = (e: React.FormEvent) => {
  e.preventDefault();
  // Validation & submit
};

<form onSubmit={handleSubmit}>
  {/* Inputs */}
</form>
```

## 📊 Mock Data Locations

### Email Listings
- **File:** `src/pages/SearchPage.tsx`
- **Variable:** `mockEmails`
- **Count:** 6 items
- **Fields:** id, email, provider, age, verified, price, seller, garansi

### Chat Messages
- **File:** `src/pages/InboxPage.tsx`
- **Variable:** `mockChats`
- **Count:** 2 chats dengan multiple messages
- **Features:** Seller rating, unread count, conversation history

### Buyer Dashboard Data
- **File:** `src/pages/BuyerDashboard.tsx`
- **Sections:**
  - MyEmails: 2 email purchases
  - TransactionHistory: 2 transactions
  - Wishlist: 2 items dengan price tracking
  - Balance: Saldo & pending info

### Seller Dashboard Data
- **File:** `src/pages/SellerDashboard.tsx`
- **Sections:**
  - ManageEmails: 2 listings
  - SalesReport: Monthly stats & recent sales
  - Withdrawal: Balance & history
  - Reviews: Rating system

## 🎨 Styling Approach

### Tailwind CSS
- Utility-first approach
- Custom colors: blue-600, green-600, red-600, yellow-600
- Responsive: sm, md, lg breakpoints
- Custom animations di `src/index.css`

### Component Styling
```typescript
// Conditional classes
className={`px-4 py-2 ${
  isActive ? 'bg-blue-600 text-white' : 'bg-gray-100'
}`}

// Using clsx (if needed)
import { clsx } from 'clsx';
className={clsx(
  'base-class',
  isActive && 'active-class'
)}
```

### Responsive Design
```typescript
// Mobile-first
<div className="w-full md:w-80 lg:w-96">
  {/* Responsive content */}
</div>

// Hidden on mobile
<aside className="hidden md:block">
  {/* Desktop sidebar */}
</aside>
```

## 🔄 State Management

### React Context + useState
```typescript
// App.tsx
const [user, setUser] = useState(null);

// Component
const { user, login, logout } = useAuth();
```

### Local Component State
```typescript
// SearchPage
const [filters, setFilters] = useState({...});
const [page, setPage] = useState(1);

// InboxPage
const [selectedChatId, setSelectedChatId] = useState(1);
const [newMessage, setNewMessage] = useState('');
```

### Derived State (useMemo)
```typescript
const filtered = useMemo(() => {
  return mockEmails.filter((email) => {
    // Filter logic
  });
}, [filters]);
```

## 🧪 Testing Data

### Demo Login
```
Email: pembeli@example.com
Password: password123
```

### Test Scenarios
1. **Register & Login Flow**
   - Go to /register → Create account
   - Go to /login → Login with demo credentials
   - Check localStorage for user data

2. **Search & Filter**
   - Use filters di SearchPage
   - Check pagination works
   - Click Detail → See DetailPage modal

3. **Buyer Dashboard**
   - /dashboard/buyer → Navigate all 5 menus
   - Check data persistence
   - Try add to wishlist, top up, etc.

4. **Seller Dashboard**
   - /dashboard/seller → Navigate all 5 menus
   - Check stats calculations
   - Try add email, withdraw, etc.

5. **Chat & Messages**
   - /inbox → Select chat
   - Send message → Update state
   - Check message order & timestamps

## 📦 Component Structure

### Page Components
- Render full page layouts
- Handle routing via Routes
- Connect to useAuth hook
- Pass data to sub-components

### Layout Components
- Header (sticky, responsive)
- Footer (static)
- DashboardSidebar (sticky, mobile toggle)

### Feature Components
- Modal dialogs
- Filter sidebar
- Email cards
- Chat bubbles
- Tables & lists

## 🔗 Navigation Flow

```
Homepage
├── Search → SearchPage
│   └── Detail → DetailPage
│       └── Buy (Modal)
├── Register → RegisterPage
│   └── Login → Dashboard
├── Login → LoginPage
│   └── Dashboard → DashboardPages
│       └── Chat → InboxPage

Authenticated User
├── /dashboard/buyer/* (5 routes)
├── /dashboard/seller/* (5 routes)
└── /inbox (shared)
```

## 🚀 Performance Optimization

### Current Implementation
- No image optimization (using ui-avatars.com)
- Mock data filtered with useMemo
- Component lazy loading not implemented
- No API calls (mocked)

### Future Improvements
- Image optimization with next/image
- Route-based code splitting
- Infinite scroll instead of pagination
- WebSocket for real-time chat
- Cache layer for API calls

## 🐛 Common Issues & Solutions

### Issue: "Cannot find module" errors
**Solution:** Check import path spelling, ensure file exists

### Issue: Tailwind styles not applied
**Solution:** Ensure class names are in index.css @import, restart dev server

### Issue: TypeScript errors
**Solution:** Use `as const` for types, check interface definitions

### Issue: State not updating in real-time chat
**Solution:** Use array spread operator for immutable updates

## 📚 File Naming Conventions

- **Pages:** PascalCase, end with `.tsx`
- **Components:** PascalCase, end with `.tsx`
- **Styles:** CSS in component or global `index.css`
- **Types:** Defined in same file or separate `types.ts`
- **Utils:** camelCase, end with `.ts`

## 🔐 Security Notes

- Passwords shown with input type toggle
- Email blur with `e***@gmail.com` format
- localStorage for demo (use secure tokens in production)
- No sensitive data in mock data
- HTTPS recommended for production

## 📝 Next Steps for Production

1. **Backend Integration**
   - Replace mock data with API calls
   - Implement real authentication
   - Setup payment gateway

2. **Database**
   - User accounts & profiles
   - Email listings & transactions
   - Chat messages
   - Ratings & reviews

3. **Features**
   - Email verification system
   - Admin panel
   - Escrow payment
   - Real-time notifications

4. **Deployment**
   - Environment variables
   - Error tracking (Sentry)
   - Analytics (GA4)
   - CDN for assets

---

**Created:** 2025  
**Last Updated:** 2025
