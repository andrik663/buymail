# 🎨 Google Login - Visual Guide & UI Preview

## 🖼️ Login Page with Google

### Desktop Layout
```
╔════════════════════════════════════════════════════════════════╗
║                                                                ║
║                    EMAILMARKET                                 ║
║                   [E] Logo                                     ║
║                                                                ║
║                  Masuk ke EmailMarket                          ║
║            Akses dashboard Anda untuk jual atau beli email     ║
║                                                                ║
╠════════════════════════════════════════════════════════════════╣
║                                                                ║
║         ┌──────────────────────────────────────────────┐      ║
║         │                                              │      ║
║         │  ► Sign in with Google                      │      ║
║         │  [Google Logo]  google_button_style        │      ║
║         │                                              │      ║
║         └──────────────────────────────────────────────┘      ║
║                                                                ║
║                    ─── atau ───                               ║
║                                                                ║
║         ┌──────────────────────────────────────────────┐      ║
║         │ 📧 Email                                     │      ║
║         │ [nama@email.com________________________]      │      ║
║         └──────────────────────────────────────────────┘      ║
║                                                                ║
║         ┌──────────────────────────────────────────────┐      ║
║         │ 🔐 Password                                  │      ║
║         │ [••••••••] [👁️ show]                        │      ║
║         └──────────────────────────────────────────────┘      ║
║                                                                ║
║         ☑ Ingat saya              [Lupa password?]            ║
║                                                                ║
║         ┌──────────────────────────────────────────────┐      ║
║         │           Masuk (Blue Button)                │      ║
║         └──────────────────────────────────────────────┘      ║
║                                                                ║
║         Belum punya akun? Daftar sekarang                      ║
║                                                                ║
╠════════════════════════════════════════════════════════════════╣
║         ✨ Demo mode aktif - Semua transaksi simulasi         ║
╚════════════════════════════════════════════════════════════════╝
```

---

## 🖼️ Register Page with Google

### Desktop Layout
```
╔════════════════════════════════════════════════════════════════╗
║                                                                ║
║                    EMAILMARKET                                 ║
║                   [E] Logo                                     ║
║                                                                ║
║                 Buat Akun EmailMarket                          ║
║              Mulai jual atau beli email premium hari ini       ║
║                                                                ║
╠════════════════════════════════════════════════════════════════╣
║                                                                ║
║         ┌──────────────────────────────────────────────┐      ║
║         │                                              │      ║
║         │  ► Sign up with Google                      │      ║
║         │  [Google Logo]  google_button_style        │      ║
║         │                                              │      ║
║         └──────────────────────────────────────────────┘      ║
║                                                                ║
║                    ─── atau ───                               ║
║                                                                ║
║         ┌──────────────────────────────────────────────┐      ║
║         │ 👤 Nama Lengkap                              │      ║
║         │ [Nama Anda________________________]           │      ║
║         └──────────────────────────────────────────────┘      ║
║                                                                ║
║         ┌──────────────────────────────────────────────┐      ║
║         │ 📧 Email                                     │      ║
║         │ [nama@email.com________________________]      │      ║
║         └──────────────────────────────────────────────┘      ║
║                                                                ║
║         ┌──────────────────────────────────────────────┐      ║
║         │ 🔐 Password                                  │      ║
║         │ [••••••••] [👁️ show]                        │      ║
║         └──────────────────────────────────────────────┘      ║
║                                                                ║
║         ┌──────────────────────────────────────────────┐      ║
║         │ 🔐 Konfirmasi Password                       │      ║
║         │ [••••••••] [👁️ show]                        │      ║
║         └──────────────────────────────────────────────┘      ║
║                                                                ║
║         Tipe Akun:                                             ║
║         ○ Pembeli - Cari & beli email premium                 ║
║         ○ Penjual - Jual email & kelola toko                  ║
║         ⦿ Keduanya - Beli & jual email                        ║
║                                                                ║
║         ┌──────────────────────────────────────────────┐      ║
║         │           Daftar (Blue Button)               │      ║
║         └──────────────────────────────────────────────┘      ║
║                                                                ║
║         Sudah punya akun? Masuk di sini                       ║
║                                                                ║
╠════════════════════════════════════════════════════════════════╣
║         ✨ Demo mode aktif - Semua transaksi simulasi         ║
╚════════════════════════════════════════════════════════════════╝
```

---

## 📱 Mobile Layout

### Login Page Mobile
```
┌─────────────────────────────┐
│                             │
│  EMAILMARKET [E]            │
│  Masuk ke EmailMarket       │
│  Akses dashboard Anda       │
│                             │
├─────────────────────────────┤
│                             │
│ ┌───────────────────────┐   │
│ │ Sign in with Google   │   │
│ │ [Google Logo]         │   │
│ └───────────────────────┘   │
│                             │
│     ─── atau ───            │
│                             │
│ 📧 Email                    │
│ [______________]            │
│                             │
│ 🔐 Password                 │
│ [______________] [👁️]      │
│                             │
│ ☑ Ingat saya                │
│ [Lupa password?]            │
│                             │
│ ┌───────────────────────┐   │
│ │ Masuk                 │   │
│ └───────────────────────┘   │
│                             │
│ Belum punya akun?           │
│ [Daftar sekarang]           │
│                             │
├─────────────────────────────┤
│ ✨ Demo mode aktif          │
└─────────────────────────────┘
```

---

## 🎯 User Journey Flow

### Authentication Path Decision
```
┌─────────────────────┐
│   User Visits       │
│   /login page       │
└──────────┬──────────┘
           │
      ┌────┴────┐
      │          │
      ▼          ▼
 ┌─────────┐  ┌──────────────┐
 │ Click   │  │ Click        │
 │ Google  │  │ Manual Login │
 │ Button  │  │ (Email/Pass) │
 └────┬────┘  └──────┬───────┘
      │              │
      ▼              ▼
 ┌─────────┐  ┌──────────────┐
 │Google   │  │Enter Email   │
 │Auth     │  │& Password    │
 │Dialog   │  │              │
 └────┬────┘  └──────┬───────┘
      │              │
      ▼              ▼
 ┌─────────┐  ┌──────────────┐
 │JWT      │  │Validate      │
 │Received │  │Credentials   │
 └────┬────┘  └──────┬───────┘
      │              │
      └────┬─────────┘
           │
           ▼
      ┌─────────┐
      │ Login   │
      │Success  │
      └────┬────┘
           │
           ▼
      ┌─────────┐
      │Toast    │
      │Success  │
      │Message  │
      └────┬────┘
           │
           ▼
      ┌─────────┐
      │Redirect │
      │to Home  │
      └─────────┘
```

---

## 🎨 Color Scheme

### Login & Register Pages
```
Background:     Slate-50 (#f8fafc)
Card:           White (#ffffff)
Border:         Slate-200 (#e2e8f0)
Shadow:         Subtle

Google Button:  Official Google Brand Colors
                (White bg, blue/gray text)

Regular Button: Blue-600 (#2563eb)
                Blue-700 on hover (#1d4ed8)

Text:           Slate-900 (#0f172a) - headings
                Slate-600 (#475569) - body
                Slate-400 (#94a3b8) - placeholders

Success Toast:  Green-500 (#22c55e)
Error Toast:    Red-500 (#ef4444)
Info Toast:     Blue-500 (#3b82f6)
Warning Toast:  Yellow-500 (#eab308)
```

---

## 🔘 Button States

### Google Login Button
```
States:
├─ Default:   White bg, Google colors, shadow
├─ Hover:     Slight shadow increase
├─ Active:    Slight depression effect
├─ Loading:   Disabled state (opacity-50)
└─ Error:     Red outline/border

Size: 350px width (responsive: 100% on mobile)
Height: ~48px
Border Radius: 4px (Google standard)
Font: Official Google font (Roboto)
```

### Email/Password Submit Button
```
States:
├─ Default:   Blue-600, white text
├─ Hover:     Blue-700 (darker)
├─ Active:    Blue-800
├─ Loading:   Opacity-50, cursor-not-allowed
└─ Disabled:  Opacity-50, cursor-not-allowed

Size: Full width (100%)
Height: 44px
Border Radius: 8px
Font: Bold, 16px
Transition: 200ms ease
```

---

## 📊 Component Hierarchy

```
App
├─ GoogleOAuthProvider
│  ├─ AppProvider
│  │  └─ ToastProvider
│  │     └─ Router
│  │        ├─ LoginPage
│  │        │  ├─ Header
│  │        │  ├─ GoogleLogin Component
│  │        │  ├─ Login Form
│  │        │  └─ Footer
│  │        │
│  │        └─ RegisterPage
│  │           ├─ Header
│  │           ├─ GoogleLogin Component
│  │           ├─ Register Form
│  │           └─ Footer
```

---

## 🎬 Animation & Transitions

### Google Button
- Default state: Shadow 0 2px 4px rgba(0,0,0,0.1)
- Hover state: Shadow 0 4px 12px rgba(0,0,0,0.15)
- Transition: 200ms cubic-bezier(0.4, 0, 0.2, 1)

### Form Inputs
- Focus: Ring-2 ring-blue-500
- Transition: 150ms ease-in-out
- Border color: Slate-300 → Blue-500 on focus

### Toast Notifications
- Slide in from top-right
- Auto-dismiss after 3-4 seconds
- Fade out animation
- Smooth easing

---

## 📐 Spacing & Layout

### Login/Register Card
```
Padding:      32px (p-8)
Border:       1px solid Slate-200
Border Radius: 8px (rounded-lg)
Shadow:       lg (0 10px 15px rgba(0,0,0,0.1))
Max Width:    448px (max-w-md)
```

### Form Fields
```
Margin Bottom:    20px (mb-5)
Label Margin:     8px (mb-2)
Input Height:     44px (py-2.5)
Input Padding:    10px left, 16px right (pl-10 pr-4)
Border Radius:    8px (rounded-lg)
```

### Google Button Container
```
Margin Bottom:    24px (mb-6)
Width:            100% or 350px
Height:           48px (auto from Google SDK)
```

---

## 🔍 Focus States (Accessibility)

### Keyboard Navigation
```
Tab Order:
1. Google Sign-in Button
2. Email Input
3. Show/Hide Password Button
4. Password Input
5. Remember Me Checkbox
6. Forgot Password Link
7. Submit Button
8. Register Link

Focus Indicator:
- Ring-2 ring-blue-500
- Offset: 2px
- Color: Blue-500 (#3b82f6)
```

---

## 🎯 Responsive Breakpoints

### Mobile (< 640px)
```
Card Width:     100% - 32px padding
Button Width:   100%
Font Size:      14px (body)
Padding:        16px (p-4 instead of p-8)
Gap:            12px (gap-3 instead of gap-5)
```

### Tablet (640px - 1024px)
```
Card Width:     448px
Button Width:   100%
Font Size:      15px (body)
Padding:        24px (p-6)
Gap:            16px (gap-4)
```

### Desktop (> 1024px)
```
Card Width:     448px
Button Width:   100%
Font Size:      16px (body)
Padding:        32px (p-8)
Gap:            20px (gap-5)
```

---

## ✨ User Feedback

### Success Scenario
```
1. User clicks Google button
2. Google dialog appears (external)
3. User authenticates
4. App receives token
5. Button shows loading state (optional)
6. Background processes login
7. Toast appears: "Selamat datang [Name]! 🎉"
   - Position: Top-right
   - Duration: 3 seconds
   - Icon: ✓ (checkmark)
   - Color: Green
8. Page redirects to home
```

### Error Scenario
```
1. User clicks Google button
2. User cancels dialog (or error occurs)
3. Toast appears: "Gagal login dengan Google"
   - Position: Top-right
   - Duration: 3 seconds
   - Icon: ✗ (cross)
   - Color: Red
4. User remains on login page
5. Can try again or use manual login
```

---

## 🎯 Design System Consistency

The Google login integration uses:
- ✅ Existing Tailwind CSS classes
- ✅ Consistent color palette (Blue-600 primary)
- ✅ Same spacing scale (4px baseline)
- ✅ Same typography (Slate colors)
- ✅ Same border radius (8px)
- ✅ Same shadow effects
- ✅ Same transition timings
- ✅ Same focus states

No custom CSS needed! Everything uses Tailwind + official Google SDK.

---

## 📱 Cross-Device Testing

✅ Desktop (1920px wide)
✅ Laptop (1366px wide)
✅ Tablet (768px wide)
✅ Mobile (375px wide)
✅ Small Mobile (320px wide)

All breakpoints render correctly with:
- Readable text
- Touchable buttons
- No horizontal scroll
- Proper spacing

---

**Status**: ✅ Complete & Production Ready
**Last Updated**: 2024
**Design Version**: 1.0
