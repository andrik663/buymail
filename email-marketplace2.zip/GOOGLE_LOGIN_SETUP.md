# 🔐 Google Login Setup Guide

## Overview
Google OAuth authentication has been integrated into the EmailMarket platform. Users can now:
- **Login with Google** on the login page
- **Register with Google** on the registration page
- Automatic account creation with Google credentials

---

## 📋 Prerequisites

1. Google Cloud Project setup
2. OAuth 2.0 Client ID
3. Authorized JavaScript origins configured

---

## 🚀 Step-by-Step Setup

### Step 1: Create a Google Cloud Project

1. Go to [Google Cloud Console](https://console.cloud.google.com/)
2. Create a new project or select an existing one
3. Enable the **Google+ API**

### Step 2: Create OAuth 2.0 Credentials

1. Go to **Credentials** in the left sidebar
2. Click **Create Credentials** → **OAuth client ID**
3. Choose **Web application**
4. Add **Authorized JavaScript origins**:
   ```
   http://localhost:5173
   http://localhost:3000
   https://yourdomain.com (for production)
   ```
5. Add **Authorized redirect URIs**:
   ```
   http://localhost:5173
   http://localhost:3000
   https://yourdomain.com (for production)
   ```
6. Copy the **Client ID**

### Step 3: Update App Configuration

Replace the `GOOGLE_CLIENT_ID` in `src/App.tsx`:

```typescript
const GOOGLE_CLIENT_ID = 'YOUR_GOOGLE_CLIENT_ID_HERE';
```

Replace `YOUR_GOOGLE_CLIENT_ID_HERE` with your actual Google Client ID from Step 2.

### Step 4: Test the Integration

1. Navigate to `/login` page
2. Click **Sign in with Google** button
3. Complete Google authentication
4. User will be logged in automatically

Or register at `/register` page with **Sign up with Google**

---

## 🔧 How It Works

### Login Flow
```
1. User clicks "Sign in with Google"
2. Google OAuth dialog appears
3. User authenticates with Google
4. JWT token received and decoded
5. User email and name extracted
6. App creates secure session
7. Redirects to dashboard
```

### Registration Flow
```
1. User clicks "Sign up with Google"
2. Google OAuth dialog appears
3. User authenticates with Google
4. JWT token received and decoded
5. New account created with role='buyer'
6. User is logged in
7. Redirects to dashboard
```

---

## 📱 Features Implemented

✅ **Google Login Button** (`LoginPage.tsx`)
- Text: "Sign in with Google"
- Styled with Google branding
- Automatic token decoding

✅ **Google Sign-up Button** (`RegisterPage.tsx`)
- Text: "Sign up with Google"
- Auto-creates account with buyer role
- Styled with Google branding

✅ **JWT Token Decoding**
- Extracts user email
- Extracts user name
- Extracts profile picture (optional)

✅ **Error Handling**
- Toast notifications for errors
- User-friendly error messages
- Fallback to manual login

✅ **Toast Notifications**
- Success: "Selamat datang [Name]! 🎉"
- Error: "Gagal login dengan Google"

---

## 🔐 Security Notes

⚠️ **Current Implementation**
- This is a **demo/development implementation**
- Passwords are auto-generated: `google_[random]`
- Tokens are decoded client-side (for demo purposes)

⚠️ **Production Implementation Should**
- Send Google token to backend
- Verify token signature on backend
- Store user securely in database
- Use proper session management
- Implement CSRF protection
- Use HTTPS only

---

## 🛠️ Installation

The package has been installed:
```bash
npm install @react-oauth/google
```

If needed, reinstall:
```bash
npm install @react-oauth/google --save
```

---

## 📦 Component Integration

### App.tsx
```typescript
import { GoogleOAuthProvider } from '@react-oauth/google';

<GoogleOAuthProvider clientId={GOOGLE_CLIENT_ID}>
  {/* Your app routes */}
</GoogleOAuthProvider>
```

### LoginPage.tsx
```typescript
import { GoogleLogin } from '@react-oauth/google';

<GoogleLogin
  onSuccess={handleGoogleSuccess}
  onError={handleGoogleError}
  text="signin_with"
  width="350"
/>
```

### RegisterPage.tsx
```typescript
import { GoogleLogin } from '@react-oauth/google';

<GoogleLogin
  onSuccess={handleGoogleSuccess}
  onError={handleGoogleError}
  text="signup_with"
  width="350"
/>
```

---

## 🧪 Testing

### Local Testing
1. Start dev server: `npm run dev`
2. Navigate to http://localhost:5173/login
3. Click "Sign in with Google"
4. Use your Google account
5. Should redirect to home page with toast notification

### Test Credentials
For manual testing without Google:
```
Email: demo@email.com
Password: 123456
```

---

## 🐛 Troubleshooting

### Issue: "Invalid Client ID"
- **Solution**: Check that Client ID is correct in `src/App.tsx`
- Ensure it matches the one from Google Cloud Console

### Issue: "Unauthorized redirect_uri"
- **Solution**: Add localhost:5173 to authorized redirect URIs
- Add production domain when deploying

### Issue: "CORS error"
- **Solution**: Ensure localhost:5173 is in Authorized JavaScript Origins
- Check browser console for exact error

### Issue: "Token decode error"
- **Solution**: Ensure JWT token is valid
- Check browser console for error details
- Verify Google Client ID is correct

---

## 🚀 Deployment Checklist

Before deploying to production:

- [ ] Replace `GOOGLE_CLIENT_ID` with production value
- [ ] Add production domain to Google Console
- [ ] Implement backend OAuth verification
- [ ] Add HTTPS support
- [ ] Test on production domain
- [ ] Enable CSRF protection
- [ ] Store tokens securely
- [ ] Implement token refresh
- [ ] Add logout functionality
- [ ] Monitor authentication logs

---

## 📚 Useful Resources

- [Google OAuth Documentation](https://developers.google.com/identity/protocols/oauth2)
- [React OAuth Google](https://www.npmjs.com/package/@react-oauth/google)
- [Google Cloud Console](https://console.cloud.google.com/)
- [JWT Token Decoder](https://jwt.io/)

---

## 💡 Next Steps

1. Complete Step 1-3 above to set up your Google Client ID
2. Test the login/register flow
3. For production, implement backend verification
4. Add token refresh mechanism
5. Implement logout functionality

---

**Status**: ✅ Integration Ready
**Last Updated**: 2024
**Version**: 1.0
