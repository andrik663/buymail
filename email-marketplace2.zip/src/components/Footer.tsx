export default function Footer() {
  return (
    <footer className="bg-slate-900 text-white mt-16 md:mt-24">
      <div className="container mx-auto px-4 py-12 md:py-16">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
          {/* Brand */}
          <div>
            <div className="flex items-center gap-2 font-bold text-lg mb-4">
              <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center text-white text-sm">
                📧
              </div>
              <span>EmailMarket</span>
            </div>
            <p className="text-slate-400 text-sm">
              Marketplace jual beli email premium terpercaya dan aman.
            </p>
          </div>

          {/* Links */}
          <div>
            <h4 className="font-semibold mb-4">Navigasi</h4>
            <ul className="space-y-2 text-sm text-slate-400">
              <li><a href="#" className="hover:text-white transition">Beranda</a></li>
              <li><a href="#" className="hover:text-white transition">Cari Email</a></li>
              <li><a href="#" className="hover:text-white transition">Cara Kerja</a></li>
              <li><a href="#" className="hover:text-white transition">FAQ</a></li>
            </ul>
          </div>

          {/* Support */}
          <div>
            <h4 className="font-semibold mb-4">Dukungan</h4>
            <ul className="space-y-2 text-sm text-slate-400">
              <li><a href="#" className="hover:text-white transition">Hubungi Kami</a></li>
              <li><a href="#" className="hover:text-white transition">Help Center</a></li>
              <li><a href="#" className="hover:text-white transition">Status Layanan</a></li>
              <li><a href="#" className="hover:text-white transition">Lapor Masalah</a></li>
            </ul>
          </div>

          {/* Legal */}
          <div>
            <h4 className="font-semibold mb-4">Informasi</h4>
            <ul className="space-y-2 text-sm text-slate-400">
              <li><a href="#" className="hover:text-white transition">Tentang Kami</a></li>
              <li><a href="#" className="hover:text-white transition">Syarat & Ketentuan</a></li>
              <li><a href="#" className="hover:text-white transition">Kebijakan Privasi</a></li>
              <li><a href="#" className="hover:text-white transition">Kebijakan Cookie</a></li>
            </ul>
          </div>
        </div>

        <div className="border-t border-slate-700 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <p className="text-sm text-slate-400">
              © 2025 EmailMarket. Semua hak dilindungi.
            </p>
            <div className="flex gap-4">
              <a href="#" className="text-slate-400 hover:text-white transition">
                <span className="text-lg">f</span>
              </a>
              <a href="#" className="text-slate-400 hover:text-white transition">
                <span className="text-lg">𝕏</span>
              </a>
              <a href="#" className="text-slate-400 hover:text-white transition">
                <span className="text-lg">💼</span>
              </a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
