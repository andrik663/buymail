# Visual Guide - Design Updates V2.0

## 1. CHAT P2P (INBOX PAGE) - Professional Two-Panel

### Layout Diagram
```
┌──────────────────────────────────────────────────────────────┐
│ Header: User Profile, Chat Icon (with badge), Notifications │
├──────────────────────────────────────────────────────────────┤
│                                                              │
│ ┌────────────────────┬─────────────────────────────────────┐ │
│ │                    │                                     │ │
│ │   CHAT LIST        │        CHAT DETAIL AREA             │ │
│ │   (280px, fixed)   │        (Flex-1, responsive)         │ │
│ │                    │                                     │ │
│ │  ┌──────────────┐  │  ┌───────────────────────────────┐ │ │
│ │  │ 🔍 Search    │  │  │ Penjual A              📋🚫🚩 │ │ │
│ │  │ [Search Bar] │  │  │ ★ 4.8 (243 reviews)         │ │ │
│ │  └──────────────┘  │  └───────────────────────────────┘ │ │
│ │                    │                                     │ │
│ │  ┌──────────────┐  │  ┌───────────────────────────────┐ │ │
│ │  │[Semua] [Unr] │  │  │ Messages                      │ │ │
│ │  │[Aktif]       │  │  │                               │ │ │
│ │  └──────────────┘  │  │  [Other] "Halo, email ini..."│ │ │
│ │                    │  │  10:30  ✓                     │ │ │
│ │  ┌──────────────┐  │  │                               │ │ │
│ │  │ Penjual A 2x │  │  │     [Me] "Ya, masih tersedia" │ │ │
│ │  │ Penjual B    │  │  │     10:35  ✓✓                 │ │ │
│ │  │ Penjual C 5x │  │  │                               │ │ │
│ │  └──────────────┘  │  └───────────────────────────────┘ │ │
│ │                    │                                     │ │
│ │                    │  ┌───────────────────────────────┐ │ │
│ │                    │  │ [Input message here] [Send →] │ │ │
│ │                    │  └───────────────────────────────┘ │ │
│ │                    │                                     │ │
│ └────────────────────┴─────────────────────────────────────┘ │
│                                                              │
└──────────────────────────────────────────────────────────────┘
```

### Color Palette
- **Header:** White with gray border
- **Sidebar background:** White
- **Selected chat:** Blue-50 background
- **User message bubble:** Blue-600 background, white text
- **Other message bubble:** White background, gray border
- **Message area background:** Gray-50
- **Input area background:** White
- **Buttons:** Blue-600 (normal), Blue-700 (hover)

### Spacing
- Left panel width: 280px (fixed)
- Right panel: flex-1 (responsive)
- Card padding: p-3, p-4
- Message padding: px-4 py-3
- Input padding: px-4 py-2.5

---

## 2. SEARCH PAGE - Filter + Email Grid

### Layout Diagram
```
┌──────────────────────────────────────────────────────────────┐
│ Header: Logo, Menu, Search, Auth                            │
├──────────────────────────────────────────────────────────────┤
│                                                              │
│ ┌──────────────────┬────────────────────────────────────┐   │
│ │                  │                                    │   │
│ │  FILTER SIDEBAR  │     RESULTS & GRID               │   │
│ │  (280px, sticky) │     (Flex-1)                     │   │
│ │                  │                                    │   │
│ │  ┌────────────┐  │  ┌──────────────────────────────┐ │   │
│ │  │ Provider   │  │  │ Ditemukan 8 Email          │ │   │
│ │  │ [✓] Gmail  │  │  │ [Tampilkan 12 ▼]           │ │   │
│ │  │ [✓] Outlook│  │  └──────────────────────────────┘ │   │
│ │  │ [ ] Yahoo  │  │                                    │   │
│ │  └────────────┘  │  ┌─────────┬─────────┬──────────┐ │   │
│ │                  │  │ Email 1 │ Email 2 │ Email 3  │ │   │
│ │  ┌────────────┐  │  │ a***@.. │ b***@.. │ c***@..  │ │   │
│ │  │ Harga      │  │  │ Gmail   │ Outlook │ Gmail    │ │   │
│ │  │ Min: [___] │  │  │ 4 tahun │ 6 tahun │ 2 tahun  │ │   │
│ │  │ Max: [___] │  │  │ ✓ Ver   │ ✓ Ver   │ ✓ Ver    │ │   │
│ │  └────────────┘  │  │ Garan7d │ Garan14 │ Garan7d  │ │   │
│ │                  │  │ Penjl A │ Penjl B │ Penjl A  │ │   │
│ │  ┌────────────┐  │  │ ★4.8    │ ★4.9    │ ★4.8     │ │   │
│ │  │ HP Verif   │  │  │ 45.000  │ 35.000  │ 55.000   │ │   │
│ │  │ [✓] Ya     │  │  │ [Detail] [♥] [💬]          │ │   │
│ │  └────────────┘  │  └─────────┴─────────┴──────────┘ │   │
│ │                  │                                    │   │
│ │  ┌────────────┐  │  ┌─────────┬─────────┬──────────┐ │   │
│ │  │ Rating Min │  │  │ Email 4 │ Email 5 │ Email 6  │ │   │
│ │  │ [⭐3+ ▼]  │  │  │ ...     │ ...     │ ...      │ │   │
│ │  └────────────┘  │  └─────────┴─────────┴──────────┘ │   │
│ │                  │                                    │   │
│ │  ┌────────────┐  │  [Prev] [1][2][3] [Next]          │   │
│ │  │[Terapkan]  │  │                                    │   │
│ │  │[Reset]     │  │                                    │   │
│ │  └────────────┘  │                                    │   │
│ │                  │                                    │   │
│ └──────────────────┴────────────────────────────────────┘   │
│                                                              │
└──────────────────────────────────────────────────────────────┘
```

### Email Card Detail
```
┌──────────────────────────────┐
│ a***@gmail.com               │  ← Bold, mono, text-sm
│ 📧 Gmail • 4 tahun 2 bulan   │  ← Gray-600, text-xs
│ ✓ HP Terverifikasi           │  ← Green badge
│ Garansi 7 hari               │  ← Blue badge
│ ──────────────────────────── │  ← Gray-100 border
│ Penjual A       ★4.8 (243)   │  ← Flex space-between
│                              │
│ Rp 45.000                    │  ← text-2xl, bold
│ Termasuk fee marketplace     │  ← text-xs, gray-500
│ ──────────────────────────── │  ← Gray-100 border
│ [Lihat Detail][♥ ][💬]       │  ← Flex gap-2, buttons
└──────────────────────────────┘
```

### Colors
- **Sidebar background:** White, shadow-sm
- **Sidebar buttons:** Blue-600 (primary), Gray-200 (secondary)
- **Card background:** White
- **Card shadow:** shadow-sm (hover: shadow-md)
- **Verified badge:** Green-50 background, Green-700 text
- **Garansi badge:** Blue-50 background, Blue-700 text
- **Price text:** Gray-900
- **Button primary:** Blue-600, hover Blue-700
- **Button secondary:** Gray-300 border, Gray-600 text

### Spacing
- Sidebar width: 280px
- Grid gap: gap-4 (16px)
- Card padding: p-4
- Section divider: pb-4 border-b border-gray-100
- Button area: px-4 pb-4

---

## 3. DETAIL PAGE - Improved Spacing

### Layout Diagram
```
┌──────────────────────────────────────────────────────────────┐
│ Header                                                       │
├──────────────────────────────────────────────────────────────┤
│                                                              │
│ ┌──────────────────────────────┬──────────────────────────┐ │
│ │                              │                          │ │
│ │  LEFT COLUMN (2/3)           │  RIGHT SIDEBAR (1/3)    │ │
│ │  (Flex cards)                │  (Sticky)               │ │
│ │                              │                          │ │
│ │  ┌────────────────────────┐  │  ┌────────────────────┐ │ │
│ │  │ Email Info Section     │  │  │ Seller Info        │ │ │
│ │  │ a***@gmail.com         │  │  │ [Avatar]           │ │ │
│ │  │ 📧 Gmail | 4 tahun     │  │  │ Penjual A          │ │ │
│ │  │ [Wishlist ♥]           │  │  │ ★ 4.8              │ │ │
│ │  └────────────────────────┘  │  └────────────────────┘ │ │
│ │                              │                          │ │
│ │  ┌────────────────────────┐  │  ┌────────────────────┐ │ │
│ │  │ Verification Status    │  │  │ Rp 45.000          │ │ │
│ │  │ ✓ HP Terverifikasi     │  │  │ Termasuk fee       │ │ │
│ │  │ ✓ Email Recovery       │  │  └────────────────────┘ │ │
│ │  │ ✗ 2FA                  │  │                          │ │
│ │  │ ✓ Tidak Suspend        │  │  ┌────────────────────┐ │ │
│ │  └────────────────────────┘  │  │ Garansi            │ │ │
│ │                              │  │ ✓ 7 hari           │ │ │
│ │  ┌────────────────────────┐  │  └────────────────────┘ │ │
│ │  │ Description            │  │                          │ │
│ │  │ Email Gmail dengan... │  │  ┌────────────────────┐ │ │
│ │  └────────────────────────┘  │  │ [Beli Sekarang]   │ │ │
│ │                              │  │ [Tanya Penjual]   │ │ │
│ │  ┌────────────────────────┐  │  └────────────────────┘ │ │
│ │  │ Screenshots            │  │                          │ │
│ │  │ [Image 1] [Image 2]    │  │                          │ │
│ │  └────────────────────────┘  │                          │ │
│ │                              │                          │ │
│ └──────────────────────────────┴──────────────────────────┘ │
│                                                              │
└──────────────────────────────────────────────────────────────┘
```

### Section Styling
```
Each section:
- Background: White
- Padding: p-5 (20px)
- Shadow: shadow-sm
- Border-radius: rounded-lg
- Margin: mb-6 between sections

Section dividers:
- pb-4 border-b border-gray-100
- Separates groups within card

Labels:
- text-xs font-bold
- UPPERCASE
- tracking-wide (letter spacing)
- text-gray-500
```

---

## 4. SPACING SCALE VISUALIZATION

### Padding
```
p-3   = 12px ████
p-4   = 16px █████
p-5   = 20px ██████
p-6   = 24px ███████
```

### Margin & Gaps
```
mb-3  = 12px ████
mb-4  = 16px █████
mb-6  = 24px ███████

gap-2 = 8px ███
gap-3 = 12px ████
gap-4 = 16px █████
```

---

## 5. COLOR PALETTE VISUALIZATION

### Primary Colors
```
Blue-600 ████████████ #2563EB (Buttons, Primary)
Blue-700 ███████████  #1D4ED8 (Hover state)
Blue-50  ███          #EFF6FF (Light background)
```

### Neutral Colors
```
Gray-900 ███████████████ #111827 (Text Primary)
Gray-600 ████████████    #4B5563 (Text Secondary)
Gray-500 ██████████      #6B7280 (Text Tertiary)
Gray-100 ███             #F3F4F6 (Light border)
White    ░░░░░░          #FFFFFF (Card background)
Gray-50  ░░░░            #F9FAFB (Light BG)
```

### Status Colors
```
Green-600 ████████████ #16A34A (Success)
Green-50  ███          #F0FDF4 (Success BG)
Yellow-500 ███████     #EABB08 (Rating star)
```

---

## 6. TYPOGRAPHY SCALE

### Font Sizes
```
text-xs    (12px) ▌▌▌ Small labels
text-sm    (14px) ▌▌▌▌ Email addresses
text-base  (16px) ▌▌▌▌▌ Body text
text-lg    (18px) ▌▌▌▌▌▌ Section titles
text-xl    (20px) ▌▌▌▌▌▌▌ Headings
text-2xl   (24px) ▌▌▌▌▌▌▌▌ Price
text-3xl   (30px) ▌▌▌▌▌▌▌▌▌ Large headings
```

### Font Weights
```
Regular (400)    "Email marketing leads"
Medium (500)     "Seller Name"
Semibold (600)   "Penjual A" ★4.8
Bold (700)       "Rp 45.000" or "Section Title"
```

### Text Combinations
```
LABEL:           text-xs font-bold UPPERCASE tracking-wide gray-500
EMAIL:           text-sm font-mono font-semibold gray-900
PRICE:           text-2xl font-bold gray-900
HEADING:         text-lg font-bold gray-900
BUTTON:          text-sm font-semibold
SMALL:           text-xs font-medium gray-600
```

---

## 7. BUTTON STYLES

### Primary Button (Apply Filter)
```
Background: Blue-600
Text: White, bold
Padding: py-2.5 px-4
Border-radius: rounded-lg
Width: w-full
Hover: Blue-700 transition
Active: Blue-800
```

### Secondary Button (Reset Filter)
```
Background: Gray-200
Text: Gray-900, bold
Padding: py-2.5 px-4
Border-radius: rounded-lg
Width: w-full
Hover: Gray-300 transition
```

### Action Button (Lihat Detail)
```
Background: Blue-600
Text: White, bold
Padding: py-2 px-4
Border-radius: rounded-lg
Flex-1: Full width of container
Icon: Optional icon
```

### Icon Button (Heart, Message)
```
Background: Transparent, border Gray-300
Icon: Gray-600 color
Padding: px-3 py-2
Border-radius: rounded-lg
Hover: bg-gray-50
```

---

## 8. RESPONSIVE BREAKPOINTS

### Desktop (lg: 1024px+)
```
Email Grid:   3 columns (gap-4)
Chat:         2-panel (280px + flex)
Filter:       Sidebar sticky at top-24
Sidebar:      Fixed width 280px
```

### Tablet (md: 768px - 1023px)
```
Email Grid:   2 columns (gap-4)
Chat:         Stacked vertical
Filter:       Full width sidebar
Layout:       Adjusted spacing
```

### Mobile (sm: < 768px)
```
Email Grid:   1 column (gap-3)
Chat:         Single panel
Filter:       Modal or full-screen
Padding:      Reduced (p-3, p-4)
Gap:          Reduced (gap-2, gap-3)
```

---

## 9. INTERACTIVE STATES

### Hover
```
Card:        shadow-sm → shadow-md (200ms transition)
Button:      Background color change + slight scale
Input:       Border color change to blue-500
Chat item:   Background to gray-50
```

### Focus
```
Input:       ring-2 ring-blue-500 + border-transparent
Button:      ring-2 ring-blue-500 outline-none
All:         focus:outline-none focus:ring-2 focus:ring-blue-500
```

### Active
```
Selected chat:  Blue-50 background + left border blue-600
Active button:  Primary color (blue-600)
Pressed:        Scale down slightly
```

### Disabled
```
Button:      opacity-50 cursor-not-allowed
Input:       cursor-not-allowed bg-gray-100
```

---

## 10. SHADOW & ELEVATION

### Depths
```
No shadow:     Flat elements (badges, text)
shadow-sm:     Cards, input fields (0 1px 2px rgba)
shadow-md:     Hover on cards (0 4px 6px rgba)
shadow-lg:     Modals, dropdowns (0 10px 15px rgba)
```

---

## Summary

**Professional Design System Implemented:**
- ✅ Consistent spacing scale
- ✅ Professional color palette
- ✅ Clear typography hierarchy
- ✅ Smooth transitions & hover states
- ✅ Responsive layouts
- ✅ Accessible color contrast
- ✅ Clean, modern appearance

**Result:** Professional, modern Email Marketplace platform ready for production! 🚀
